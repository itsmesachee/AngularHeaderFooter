import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ViewComponent} from './components/view/view.component';
import {AddComponent} from './components/add/add.component';
import {UpdateComponent} from './components/update/update.component'
const routes: Routes = [

  { path: 'view', component: ViewComponent },
  { path: 'add', component: AddComponent },
  { path: 'update',component:UpdateComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
